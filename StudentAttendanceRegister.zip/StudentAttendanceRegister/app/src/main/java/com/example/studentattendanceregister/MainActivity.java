package com.example.studentattendanceregister;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends Activity {

    private EditText studentNameInput;
    private Button addStudentButton;
    private ListView studentListView;
    private TextView attendanceSummary;
    private TextView emptyMessage;

    private final ArrayList<Student> students = new ArrayList<>();
    private StudentAdapter adapter;

    private static class Student {
        String name;
        boolean present;

        Student(String name) {
            this.name = name;
            this.present = false;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        studentNameInput =
                findViewById(R.id.studentNameInput);
        addStudentButton =
                findViewById(R.id.addStudentButton);
        studentListView =
                findViewById(R.id.studentListView);
        attendanceSummary =
                findViewById(R.id.attendanceSummary);
        emptyMessage =
                findViewById(R.id.emptyMessage);

        adapter = new StudentAdapter();
        studentListView.setAdapter(adapter);

        addStudentButton.setOnClickListener(
                view -> addStudent()
        );

        updateSummary();
    }

    private void addStudent() {
        String name = studentNameInput.getText()
                .toString().trim();

        if (name.isEmpty()) {
            studentNameInput.setError(
                    "Enter the student's name"
            );
            studentNameInput.requestFocus();
            return;
        }

        students.add(new Student(name));
        studentNameInput.setText("");

        updateSummary();

        Toast.makeText(
                this,
                "Student added successfully",
                Toast.LENGTH_SHORT
        ).show();
    }

    private void updateSummary() {
        int presentCount = 0;

        for (Student student : students) {
            if (student.present) {
                presentCount++;
            }
        }

        int total = students.size();
        int absentCount = total - presentCount;

        attendanceSummary.setText(
                "Total: " + total
                        + " | Present: " + presentCount
                        + " | Absent: " + absentCount
        );

        emptyMessage.setVisibility(
                students.isEmpty()
                        ? View.VISIBLE : View.GONE
        );

        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
    }

    private class StudentAdapter extends BaseAdapter {

        private final LayoutInflater inflater =
                LayoutInflater.from(MainActivity.this);

        @Override
        public int getCount() {
            return students.size();
        }

        @Override
        public Object getItem(int position) {
            return students.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(
                int position,
                View convertView,
                ViewGroup parent) {

            View row = inflater.inflate(
                    R.layout.student_item,
                    parent,
                    false
            );

            Student student = students.get(position);

            TextView nameText =
                    row.findViewById(R.id.studentNameText);

            RadioGroup radioGroup =
                    row.findViewById(
                            R.id.attendanceRadioGroup
                    );

            RadioButton presentRadio =
                    row.findViewById(R.id.presentRadio);

            RadioButton absentRadio =
                    row.findViewById(R.id.absentRadio);

            nameText.setText(student.name);

            // Set the saved status before adding the listener.
            presentRadio.setChecked(student.present);
            absentRadio.setChecked(!student.present);

            row.setBackgroundColor(
                    student.present
                            ? 0xFFE8F5E9
                            : 0xFFFFEBEE
            );

            radioGroup.setOnCheckedChangeListener(
                    (group, checkedId) -> {
                        if (checkedId == R.id.presentRadio) {
                            student.present = true;
                        } else if (checkedId == R.id.absentRadio) {
                            student.present = false;
                        }

                        row.setBackgroundColor(
                                student.present
                                        ? 0xFFE8F5E9
                                        : 0xFFFFEBEE
                        );

                        updateSummary();
                    }
            );

            return row;
        }
    }
}